import fs from "fs";
import path from "path";
import zlib from "zlib";

function createPng(width, height, getPixel) {
  // PNG signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr.writeUInt8(8, 8); // 8 bit depth
  ihdr.writeUInt8(6, 9); // RGBA color type
  ihdr.writeUInt8(0, 10); // compression
  ihdr.writeUInt8(0, 11); // filter
  ihdr.writeUInt8(0, 12); // interlace

  const ihdrChunk = createChunk("IHDR", ihdr);

  // Raw image data with 0 filter byte per scanline
  const scanlineLength = 1 + width * 4;
  const rawData = Buffer.alloc(scanlineLength * height);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * scanlineLength;
    rawData[rowOffset] = 0; // Filter type 0: None
    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const [r, g, b, a] = getPixel(x, y, width, height);
      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  const compressed = zlib.deflateSync(rawData);
  const idatChunk = createChunk("IDAT", compressed);
  const iendChunk = createChunk("IEND", Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function createChunk(type, data) {
  const len = data.length;
  const chunk = Buffer.alloc(8 + len + 4);
  chunk.writeUInt32BE(len, 0);
  chunk.write(type, 4, 4, "ascii");
  data.copy(chunk, 8);

  const crcTarget = chunk.subarray(4, 8 + len);
  const crcVal = crc32(crcTarget);
  chunk.writeInt32BE(crcVal, 8 + len);
  return chunk;
}

// CRC32 implementation
let crcTable = null;
function getCrcTable() {
  if (crcTable) return crcTable;
  crcTable = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      if (c & 1) {
        c = 0xedb88320 ^ (c >>> 1);
      } else {
        c = c >>> 1;
      }
    }
    crcTable[n] = c;
  }
  return crcTable;
}

function crc32(buf) {
  const table = getCrcTable();
  let c = -1;
  for (let i = 0; i < buf.length; i++) {
    c = table[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ -1);
}

// Draw futuristic icon for Myraa
function myraaPixel(x, y, w, h, isMaskable) {
  const cx = w / 2;
  const cy = h / 2;
  const dx = x - cx;
  const dy = y - cy;
  const dist = Math.sqrt(dx * dx + dy * dy);
  const maxR = w * (isMaskable ? 0.38 : 0.44);

  // Background
  const bgGrad = y / h;
  const rBg = Math.round(7 + bgGrad * 12);
  const gBg = Math.round(7 + bgGrad * 6);
  const bBg = Math.round(20 + bgGrad * 24);

  if (dist < maxR * 0.35) {
    // Inner core star
    return [255, 255, 255, 255];
  } else if (dist < maxR * 0.7) {
    // Glowing gradient cyan to violet
    const t = (dist - maxR * 0.35) / (maxR * 0.35);
    const r = Math.round(56 + t * (168 - 56));
    const g = Math.round(189 - t * (189 - 85));
    const b = Math.round(248 + t * (247 - 248));
    return [r, g, b, 255];
  } else if (dist < maxR) {
    // Outer halo
    const t = (dist - maxR * 0.7) / (maxR * 0.3);
    const alpha = Math.round(255 * (1 - t * 0.6));
    return [168, 85, 247, alpha];
  }

  // Base background
  return [rBg, gBg, bBg, 255];
}

const publicDir = path.join(process.cwd(), "public");
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// 192x192
fs.writeFileSync(path.join(publicDir, "pwa-192x192.png"), createPng(192, 192, (x, y, w, h) => myraaPixel(x, y, w, h, false)));
// 512x512
fs.writeFileSync(path.join(publicDir, "pwa-512x512.png"), createPng(512, 512, (x, y, w, h) => myraaPixel(x, y, w, h, false)));
// 512x512 Maskable
fs.writeFileSync(path.join(publicDir, "pwa-maskable-512x512.png"), createPng(512, 512, (x, y, w, h) => myraaPixel(x, y, w, h, true)));
// apple-touch-icon 180x180
fs.writeFileSync(path.join(publicDir, "apple-touch-icon.png"), createPng(180, 180, (x, y, w, h) => myraaPixel(x, y, w, h, false)));
// favicon.ico (can be a small png)
fs.writeFileSync(path.join(publicDir, "favicon.ico"), createPng(64, 64, (x, y, w, h) => myraaPixel(x, y, w, h, false)));

console.log("PWA Icons created successfully!");
