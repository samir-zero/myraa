import JSZip from "jszip";
import fs from "fs/promises";
import path from "path";

export async function generateAndroidProjectZip(appUrl: string): Promise<Buffer> {
  const zip = new JSZip();

  const packageId = "com.myraa.ai.companion";
  const appName = "Remix Myraa AI Assistant";
  const shortName = "Myraa";
  const hostUrl = appUrl.replace(/^https?:\/\//, "").replace(/\/.*$/, "");
  const targetUrl = appUrl.startsWith("http") ? appUrl : `https://${appUrl}`;

  // 1. Root build.gradle
  const rootBuildGradle = `// Top-level build file for Myraa Android TWA Application
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.2.2'
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
`;
  zip.file("build.gradle", rootBuildGradle);

  // 2. settings.gradle
  const settingsGradle = `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "MyraaAI"
include ':app'
`;
  zip.file("settings.gradle", settingsGradle);

  // 3. gradle.properties
  const gradleProperties = `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
android.nonTransitiveRClass=true
`;
  zip.file("gradle.properties", gradleProperties);

  // 4. app/build.gradle
  const appBuildGradle = `plugins {
    id 'com.android.application'
}

android {
    namespace '${packageId}'
    compileSdk 34

    defaultConfig {
        applicationId "${packageId}"
        minSdk 21
        targetSdk 34
        versionCode 1
        versionName "1.0.0"

        manifestPlaceholders = [
            hostName: "${hostUrl}",
            defaultUrl: "${targetUrl}",
            launcherName: "${shortName}"
        ]
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'androidx.browser:browser:1.8.0'
    implementation 'com.google.androidbrowserhelper:androidbrowserhelper:2.5.0'
}
`;
  zip.file("app/build.gradle", appBuildGradle);

  // 5. app/proguard-rules.pro
  zip.file("app/proguard-rules.pro", "# Myraa Proguard Rules\n-keepattributes *Annotation*\n");

  // 6. app/src/main/AndroidManifest.xml
  const androidManifest = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.FLASHLIGHT" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="${appName}"
        android:roundIcon="@mipmap/ic_launcher"
        android:supportsRtl="true"
        android:theme="@style/Theme.Myraa">

        <meta-data
            android:name="asset_statements"
            android:resource="@string/asset_statements" />

        <activity
            android:name="com.google.androidbrowserhelper.trusted.LauncherActivity"
            android:label="${shortName}"
            android:exported="true"
            android:theme="@style/Theme.Myraa">

            <meta-data
                android:name="android.support.customtabs.trusted.DEFAULT_URL"
                android:value="${targetUrl}" />

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data
                    android:scheme="https"
                    android:host="${hostUrl}" />
            </intent-filter>
        </activity>

    </application>

</manifest>
`;
  zip.file("app/src/main/AndroidManifest.xml", androidManifest);

  // 7. app/src/main/res/values/strings.xml
  const stringsXml = `<resources>
    <string name="app_name">${appName}</string>
    <string name="asset_statements">[{\\"relation\\": [\\"delegate_permission/common.handle_all_urls\\"], \\"target\\": {\\"namespace\\": \\"web\\", \\"site\\": \\"${targetUrl}\\"}}]</string>
</resources>
`;
  zip.file("app/src/main/res/values/strings.xml", stringsXml);

  // 8. app/src/main/res/values/styles.xml
  const stylesXml = `<resources>
    <style name="Theme.Myraa" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="android:statusBarColor">#020205</item>
        <item name="android:navigationBarColor">#020205</item>
        <item name="android:windowBackground">#020205</item>
    </style>
</resources>
`;
  zip.file("app/src/main/res/values/styles.xml", stylesXml);

  // 9. Read app icon if available and embed into mipmap
  try {
    const icon192 = await fs.readFile(path.join(process.cwd(), "public", "pwa-192x192.png"));
    zip.file("app/src/main/res/mipmap/ic_launcher.png", icon192);
  } catch (e) {
    // optional icon fallback
  }

  // 10. Digital assetlinks & twa-manifest
  try {
    const assetlinks = await fs.readFile(path.join(process.cwd(), "public", ".well-known", "assetlinks.json"), "utf-8");
    zip.file("assetlinks.json", assetlinks);
  } catch (e) {}

  try {
    const twaManifest = await fs.readFile(path.join(process.cwd(), "public", "twa-manifest.json"), "utf-8");
    zip.file("twa-manifest.json", twaManifest);
  } catch (e) {}

  // 11. README with direct build instructions
  const readme = `# Myraa AI Companion - Android Studio / Standalone APK Project

This project contains everything needed to build a native Android APK or Google Play Store bundle (.aab) for Myraa.

## 🚀 How to build the APK (2 simple ways)

### Method 1: Using Android Studio (Recommended)
1. Download and extract this \`myraa-android-project.zip\`.
2. Open **Android Studio** and select **"Open an Existing Project"**.
3. Choose the extracted folder.
4. Go to **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
5. In 1 minute, Android Studio will generate \`app-debug.apk\`.
6. Transfer this \`.apk\` to your Android phone and install!

### Method 2: Command Line (Gradle)
\`\`\`bash
# Linux / macOS:
chmod +x gradlew
./gradlew assembleDebug

# Windows:
gradlew.bat assembleDebug
\`\`\`
The generated APK file will be located at:
\`app/build/outputs/apk/debug/app-debug.apk\`

---

## 📲 Direct WebAPK Install on Mobile (Fastest - No Build Needed)
You can also open the web app directly in **Google Chrome on your Android Phone**:
1. Tap the **"INSTALL APP ON MOBILE"** button or Chrome menu (3 dots ⋮) > **"Install App"**.
2. Android will automatically create and install the native **WebAPK** to your App Drawer!
`;
  zip.file("README.md", readme);

  return await zip.generateAsync({ type: "nodebuffer" });
}
