# Myraa — App banane ke steps

## 1. Server deploy karo (HTTPS URL chahiye)
Render / Railway / Google Cloud Run (Dockerfile already included).
Environment variable set karo: GEMINI_API_KEY = <apni key>
Deploy ke baad URL milega, e.g. https://myraa.onrender.com

## 2. Phone pe install (sabse easy, 2 min)
Chrome me URL kholo -> menu -> "Install app" / "Add to Home screen".

## 3. Real APK (optional)
1. https://www.pwabuilder.com pe apna URL daalo -> Package for Android -> Download.
2. Ya Bubblewrap: public/twa-manifest.json me "host" aur icon URLs apne naye URL se badlo,
   phir `npx @bubblewrap/cli init --manifest=https://<URL>/manifest.webmanifest` -> `bubblewrap build`.
3. APK ka SHA-256 fingerprint public/.well-known/assetlinks.json me daalo, redeploy karo
   (warna app me URL bar dikhega).
