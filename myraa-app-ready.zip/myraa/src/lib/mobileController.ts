/**
 * Mobile Controller & Background Service for Myraa AI Assistant.
 * Provides:
 * - App Deep Linking (WhatsApp, Phone, SMS, Maps, YouTube, Camera, Alarm, Calculator, Settings, etc.)
 * - Hardware Torch / Flashlight control (with screen flashlight fallback)
 * - Haptic feedback / Device Vibration
 * - Battery & Network Diagnostics
 * - System Notifications & Web Share
 * - Background Audio Keep-Alive (MediaSession API + Silent Loop Player)
 * - Picture-in-Picture (PiP) Floating Avatar Mode for background multitasking
 * - Screen WakeLock API
 * - Mobile Back-button interceptor to prevent accidental closure
 * - Mobile Camera Vision (Rear/Front camera stream for real-time video inspection)
 */

export interface BatteryInfo {
  level: number; // 0 - 100
  charging: boolean;
  chargingTime: number;
  dischargingTime: number;
}

export interface DeviceDiagnostics {
  battery: BatteryInfo | null;
  online: boolean;
  networkType: string;
  screenSize: string;
  isStandalone: boolean;
  torchSupported: boolean;
  vibrateSupported: boolean;
}

class MobileController {
  private torchTrack: MediaStreamTrack | null = null;
  private torchStream: MediaStream | null = null;
  private isTorchOn = false;
  private screenFlashlightActive = false;
  private screenFlashlightOverlay: HTMLDivElement | null = null;

  private wakeLock: any = null;
  private silentAudio: HTMLAudioElement | null = null;
  private pipVideo: HTMLVideoElement | null = null;
  private pipCanvas: HTMLCanvasElement | null = null;
  private pipAnimationId: number | null = null;
  private isPipActive = false;

  private cameraStream: MediaStream | null = null;

  constructor() {
    this.initBackgroundAudio();
  }

  // ==========================================
  // 1. APP LAUNCHERS & SYSTEM INTENTS
  // ==========================================

  public openMobileApp(app: string, target?: string): { success: boolean; message: string } {
    const cleanApp = app.toLowerCase();
    const query = target || "";

    try {
      switch (cleanApp) {
        case "whatsapp": {
          if (query) {
            // Check if phone number or message
            const hasPhone = /^\+?[0-9]{7,15}$/.test(query.replace(/[\s-]/g, ""));
            if (hasPhone) {
              const num = query.replace(/[^0-9]/g, "");
              window.location.href = `https://wa.me/${num}`;
            } else {
              window.location.href = `whatsapp://send?text=${encodeURIComponent(query)}`;
            }
          } else {
            window.location.href = "whatsapp://";
          }
          return { success: true, message: `WhatsApp opened${query ? ` with target: "${query}"` : ""}.` };
        }

        case "phone":
        case "call":
        case "dialer": {
          const cleanNum = query.replace(/[^0-9+]/g, "") || "123";
          window.location.href = `tel:${cleanNum}`;
          return { success: true, message: `Phone dialer opened for ${cleanNum}.` };
        }

        case "sms":
        case "message": {
          const body = encodeURIComponent(query);
          window.location.href = `sms:?body=${body}`;
          return { success: true, message: `SMS application opened with pre-filled text.` };
        }

        case "maps":
        case "navigation":
        case "location": {
          const mapUrl = query
            ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`
            : "https://www.google.com/maps";
          window.open(mapUrl, "_blank");
          return { success: true, message: `Google Maps opened for "${query || "current location"}".` };
        }

        case "youtube": {
          const ytUrl = query
            ? `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`
            : "https://www.youtube.com";
          window.open(ytUrl, "_blank");
          return { success: true, message: `YouTube opened searching for "${query}".` };
        }

        case "camera": {
          // Trigger system camera file selector
          const input = document.createElement("input");
          input.type = "file";
          input.accept = "image/*";
          input.capture = "environment";
          input.click();
          return { success: true, message: "Device camera triggered." };
        }

        case "email":
        case "mail": {
          window.location.href = `mailto:?subject=${encodeURIComponent(query || "Myraa Companion Note")}`;
          return { success: true, message: "Email client opened." };
        }

        case "search":
        case "google": {
          window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, "_blank");
          return { success: true, message: `Google search performed for "${query}".` };
        }

        case "alarm":
        case "clock":
        case "timer": {
          // In Android, intent clock:// or trigger browser timer
          this.setWebTimer(parseInt(query, 10) || 60, "Myraa Timer Alert!");
          return { success: true, message: `Timer started for ${query || "60"} seconds.` };
        }

        case "calculator": {
          // Web calculation or calculator launcher
          window.open("https://www.google.com/search?q=calculator", "_blank");
          return { success: true, message: "Calculator opened." };
        }

        case "settings": {
          return { success: true, message: "Please open your phone Settings from the notifications drawer." };
        }

        default: {
          window.open(`https://www.google.com/search?q=${encodeURIComponent(app + " " + query)}`, "_blank");
          return { success: true, message: `Opened search for ${app}.` };
        }
      }
    } catch (e: any) {
      return { success: false, message: `Failed opening ${app}: ${e.message}` };
    }
  }

  // ==========================================
  // 2. FLASHLIGHT / TORCH CONTROL
  // ==========================================

  public async toggleTorch(requestedState?: boolean): Promise<{ success: boolean; state: boolean; mode: string }> {
    const targetState = requestedState !== undefined ? requestedState : !this.isTorchOn;

    try {
      // 1. Try Hardware Camera Torch
      if (targetState) {
        if (!this.torchStream) {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: "environment",
              // @ts-ignore
              advanced: [{ torch: true }],
            },
          });
          this.torchStream = stream;
          const track = stream.getVideoTracks()[0];
          this.torchTrack = track;
        }

        if (this.torchTrack) {
          // @ts-ignore
          await this.torchTrack.applyConstraints({ advanced: [{ torch: true }] });
          this.isTorchOn = true;
          this.removeScreenFlashlight();
          return { success: true, state: true, mode: "hardware_torch" };
        }
      } else {
        if (this.torchTrack) {
          // @ts-ignore
          await this.torchTrack.applyConstraints({ advanced: [{ torch: false }] }).catch(() => {});
        }
        if (this.torchStream) {
          this.torchStream.getTracks().forEach((t) => t.stop());
          this.torchStream = null;
          this.torchTrack = null;
        }
        this.isTorchOn = false;
        this.removeScreenFlashlight();
        return { success: true, state: false, mode: "hardware_torch" };
      }
    } catch (hardwareError) {
      console.warn("[Torch] Hardware torch unavailable, using Screen Flashlight fallback:", hardwareError);
    }

    // 2. Screen Flashlight Fallback (100% white screen overlay)
    if (targetState) {
      this.createScreenFlashlight();
      this.isTorchOn = true;
      return { success: true, state: true, mode: "screen_flashlight" };
    } else {
      this.removeScreenFlashlight();
      this.isTorchOn = false;
      return { success: true, state: false, mode: "screen_flashlight" };
    }
  }

  private createScreenFlashlight() {
    if (this.screenFlashlightOverlay) return;
    const overlay = document.createElement("div");
    overlay.id = "myraa-screen-flashlight";
    overlay.style.cssText =
      "position:fixed;inset:0;background:#ffffff;z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;";
    overlay.innerHTML = `
      <div style="color:#000;font-family:sans-serif;font-weight:700;font-size:20px;text-align:center;padding:24px;border:3px solid #000;border-radius:16px;">
        💡 SCREEN FLASHLIGHT ACTIVE<br/>
        <span style="font-size:14px;font-weight:400;opacity:0.8;">Tap anywhere to turn off</span>
      </div>
    `;
    overlay.onclick = () => {
      this.toggleTorch(false);
    };
    document.body.appendChild(overlay);
    this.screenFlashlightOverlay = overlay;
    this.screenFlashlightActive = true;
  }

  private removeScreenFlashlight() {
    if (this.screenFlashlightOverlay) {
      this.screenFlashlightOverlay.remove();
      this.screenFlashlightOverlay = null;
      this.screenFlashlightActive = false;
    }
  }

  public getTorchState(): boolean {
    return this.isTorchOn;
  }

  // ==========================================
  // 3. HAPTICS / VIBRATION
  // ==========================================

  public vibrate(pattern: number | number[] = [150, 80, 150]): boolean {
    try {
      if (typeof navigator !== "undefined" && "vibrate" in navigator) {
        return navigator.vibrate(pattern);
      }
    } catch (e) {
      console.warn("Vibration not permitted or unsupported:", e);
    }
    return false;
  }

  // ==========================================
  // 4. BATTERY & DEVICE DIAGNOSTICS
  // ==========================================

  public async getBattery(): Promise<BatteryInfo | null> {
    try {
      // @ts-ignore
      if (typeof navigator !== "undefined" && "getBattery" in navigator) {
        // @ts-ignore
        const battery = await navigator.getBattery();
        return {
          level: Math.round(battery.level * 100),
          charging: battery.charging,
          chargingTime: battery.chargingTime,
          dischargingTime: battery.dischargingTime,
        };
      }
    } catch (e) {
      console.warn("Battery API unavailable:", e);
    }
    return null;
  }

  public async getDiagnostics(): Promise<DeviceDiagnostics> {
    const battery = await this.getBattery();
    const online = typeof navigator !== "undefined" ? navigator.onLine : true;
    // @ts-ignore
    const conn = typeof navigator !== "undefined" ? (navigator.connection || navigator.mozConnection || navigator.webkitConnection) : null;
    const networkType = conn ? conn.effectiveType || conn.type || "online" : online ? "connected" : "offline";

    const isStandalone =
      typeof window !== "undefined" &&
      (window.matchMedia("(display-mode: standalone)").matches ||
        (window.navigator as any).standalone === true);

    return {
      battery,
      online,
      networkType,
      screenSize: typeof window !== "undefined" ? `${window.innerWidth}x${window.innerHeight}` : "unknown",
      isStandalone,
      torchSupported: typeof navigator !== "undefined" && !!navigator.mediaDevices,
      vibrateSupported: typeof navigator !== "undefined" && "vibrate" in navigator,
    };
  }

  // ==========================================
  // 5. CLIPBOARD & SHARE
  // ==========================================

  public async copyToClipboard(text: string): Promise<boolean> {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(text);
        this.vibrate(50);
        return true;
      }
    } catch (e) {
      console.warn("Clipboard write failed:", e);
    }
    return false;
  }

  public async share(content: { title?: string; text?: string; url?: string }): Promise<boolean> {
    try {
      if (navigator.share) {
        await navigator.share(content);
        return true;
      }
    } catch (e) {
      console.warn("Web Share aborted or failed:", e);
    }
    return false;
  }

  // ==========================================
  // 6. TIMER & NOTIFICATION
  // ==========================================

  public setWebTimer(seconds: number, label: string = "Myraa Alarm") {
    setTimeout(() => {
      this.vibrate([300, 150, 300, 150, 500]);
      this.showNotification("⏰ " + label, `Time's up! ${seconds} seconds completed.`);
      try {
        const audio = new Audio("https://actions.google.com/sounds/v1/alarms/alarm_clock.ogg");
        audio.play().catch(() => {});
      } catch (e) {}
    }, seconds * 1000);
  }

  public async showNotification(title: string, body: string): Promise<boolean> {
    try {
      if (!("Notification" in window)) return false;
      if (Notification.permission === "granted") {
        new Notification(title, { body, icon: "/pwa-192x192.png" });
        return true;
      } else if (Notification.permission !== "denied") {
        const perm = await Notification.requestPermission();
        if (perm === "granted") {
          new Notification(title, { body, icon: "/pwa-192x192.png" });
          return true;
        }
      }
    } catch (e) {
      console.warn("Notification trigger failed:", e);
    }
    return false;
  }

  // ==========================================
  // 7. BACKGROUND AUDIO KEEP-ALIVE & MEDIA SESSION
  // ==========================================

  private initBackgroundAudio() {
    try {
      // Creates an ultra-low volume looping audio element using a microscopic silent WAV data URI
      // This signals Android OS and iOS WebKit that audio playback is active, preventing background tab suspension
      const silentWavBase64 =
        "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=";
      const audio = new Audio(silentWavBase64);
      audio.loop = true;
      audio.volume = 0.01;
      this.silentAudio = audio;

      // Register MediaSession metadata so Android lock screen & notification tray show Myraa
      if ("mediaSession" in navigator) {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: "Myraa AI Companion",
          artist: "Voice & Vision Connected",
          album: "Live AI Mobile Assistant",
          artwork: [
            { src: "/pwa-192x192.png", sizes: "192x192", type: "image/png" },
            { src: "/pwa-512x512.png", sizes: "512x512", type: "image/png" },
          ],
        });

        navigator.mediaSession.setActionHandler("play", () => {
          this.startBackgroundAudio();
        });
        navigator.mediaSession.setActionHandler("pause", () => {
          this.stopBackgroundAudio();
        });
        navigator.mediaSession.setActionHandler("stop", () => {
          this.stopBackgroundAudio();
        });
      }
    } catch (e) {
      console.warn("Background audio setup notice:", e);
    }
  }

  public startBackgroundAudio() {
    if (this.silentAudio) {
      this.silentAudio.play().catch(() => {});
    }
  }

  public stopBackgroundAudio() {
    if (this.silentAudio) {
      this.silentAudio.pause();
    }
  }

  // ==========================================
  // 8. SCREEN WAKE LOCK
  // ==========================================

  public async acquireWakeLock(): Promise<boolean> {
    try {
      // @ts-ignore
      if ("wakeLock" in navigator && !this.wakeLock) {
        // @ts-ignore
        this.wakeLock = await navigator.wakeLock.request("screen");
        this.wakeLock.addEventListener("release", () => {
          this.wakeLock = null;
        });
        return true;
      }
    } catch (e) {
      console.warn("Wake lock failed:", e);
    }
    return false;
  }

  public releaseWakeLock() {
    if (this.wakeLock) {
      try {
        this.wakeLock.release();
      } catch (e) {}
      this.wakeLock = null;
    }
  }

  // ==========================================
  // 9. PICTURE-IN-PICTURE (PiP) FLOATING AVATAR WIDGET
  // ==========================================

  public async togglePictureInPicture(
    avatarCanvasProvider?: () => HTMLCanvasElement | null
  ): Promise<boolean> {
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        this.isPipActive = false;
        return false;
      }

      if (!document.pictureInPictureEnabled) {
        console.warn("Picture in Picture not enabled in browser.");
        return false;
      }

      if (!this.pipCanvas) {
        this.pipCanvas = document.createElement("canvas");
        this.pipCanvas.width = 360;
        this.pipCanvas.height = 360;
      }

      const canvas = this.pipCanvas;
      const ctx = canvas.getContext("2d");
      if (!ctx) return false;

      // Animate floating avatar on PiP canvas
      const renderPip = () => {
        if (!ctx) return;
        ctx.fillStyle = "#020205";
        ctx.fillRect(0, 0, 360, 360);

        // Ambient glowing rings
        const time = Date.now() * 0.003;
        const grad = ctx.createRadialGradient(180, 180, 20, 180, 180, 160);
        grad.addColorStop(0, "rgba(56, 189, 248, 0.4)");
        grad.addColorStop(0.5, "rgba(168, 85, 247, 0.25)");
        grad.addColorStop(1, "rgba(2, 2, 5, 0)");
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(180, 180, 160, 0, Math.PI * 2);
        ctx.fill();

        // Pulsing core orb
        const pulse = Math.sin(time * 2) * 10;
        ctx.save();
        ctx.shadowColor = "#38bdf8";
        ctx.shadowBlur = 25;
        ctx.fillStyle = "#a855f7";
        ctx.beginPath();
        ctx.arc(180, 180, 50 + pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // White inner star
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(180, 180, 18, 0, Math.PI * 2);
        ctx.fill();

        // Text banner
        ctx.font = "bold 16px sans-serif";
        ctx.fillStyle = "#ffffff";
        ctx.textAlign = "center";
        ctx.fillText("MYRAA ACTIVE", 180, 280);

        ctx.font = "12px monospace";
        ctx.fillStyle = "#38bdf8";
        ctx.fillText("Voice & Vision Listening...", 180, 305);

        this.pipAnimationId = requestAnimationFrame(renderPip);
      };

      renderPip();

      // Stream to video element
      if (!this.pipVideo) {
        this.pipVideo = document.createElement("video");
        this.pipVideo.muted = true;
        this.pipVideo.playsInline = true;
      }

      // @ts-ignore
      const stream = canvas.captureStream(15);
      this.pipVideo.srcObject = stream;
      await this.pipVideo.play();
      await this.pipVideo.requestPictureInPicture();
      this.isPipActive = true;

      this.pipVideo.addEventListener(
        "leavepictureinpicture",
        () => {
          this.isPipActive = false;
          if (this.pipAnimationId) {
            cancelAnimationFrame(this.pipAnimationId);
            this.pipAnimationId = null;
          }
        },
        { once: true }
      );

      return true;
    } catch (e: any) {
      console.warn("Picture in Picture request error:", e);
      return false;
    }
  }

  public isPictureInPictureActive(): boolean {
    return !!document.pictureInPictureElement || this.isPipActive;
  }

  // ==========================================
  // 10. MOBILE BACK-BUTTON INTERCEPTOR
  // ==========================================

  public setupBackButtonProtection(onBackAttempt: () => void): () => void {
    if (typeof window === "undefined") return () => {};

    // Push initial guard state to history
    window.history.pushState({ myraaActive: true }, "");

    const handlePopState = (e: PopStateEvent) => {
      // Re-push state so user doesn't exit by accident
      window.history.pushState({ myraaActive: true }, "");
      onBackAttempt();
    };

    window.addEventListener("popstate", handlePopState);

    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }

  // ==========================================
  // 11. MOBILE CAMERA STREAM (REAR/FRONT VISION)
  // ==========================================

  public async startCameraVision(facingMode: "environment" | "user" = "environment"): Promise<MediaStream | null> {
    try {
      if (this.cameraStream) {
        this.cameraStream.getTracks().forEach((t) => t.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: facingMode },
          width: { ideal: 1280 },
          height: { ideal: 720 },
          frameRate: { ideal: 5 },
        },
        audio: false,
      });

      this.cameraStream = stream;
      return stream;
    } catch (e: any) {
      console.error("Camera vision stream error:", e);
      return null;
    }
  }

  public stopCameraVision() {
    if (this.cameraStream) {
      this.cameraStream.getTracks().forEach((t) => {
        try {
          t.stop();
        } catch (e) {}
      });
      this.cameraStream = null;
    }
  }

  public getCameraStream(): MediaStream | null {
    return this.cameraStream;
  }
}

export const mobileController = new MobileController();
