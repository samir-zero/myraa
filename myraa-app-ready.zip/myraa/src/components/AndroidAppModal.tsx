import React, { useState } from "react";
import { 
  Smartphone, 
  Download, 
  ExternalLink, 
  CheckCircle2, 
  Copy, 
  Check, 
  X, 
  ShieldCheck, 
  Zap, 
  Layers, 
  Eye, 
  Flashlight, 
  Vibrate, 
  Sparkles,
  FolderArchive,
  Info,
  Globe
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { usePWAInstall } from "../lib/usePWAInstall";

interface AndroidAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidAppModal: React.FC<AndroidAppModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<"install" | "apk" | "features">("install");
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);

  // Determine current active origin
  const origin = typeof window !== "undefined" ? window.location.origin : "https://myraa-ai.app";
  const [customUrl, setCustomUrl] = useState(origin);

  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(customUrl)}`;

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(customUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleInstallClick = async () => {
    if (isInstallable) {
      await install();
    }
  };

  const handleDownloadProjectZip = () => {
    setIsDownloadingZip(true);
    const downloadUrl = `/api/download-android-project?url=${encodeURIComponent(customUrl)}`;
    const link = document.createElement("a");
    link.href = downloadUrl;
    link.setAttribute("download", "myraa-android-project.zip");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => setIsDownloadingZip(false), 1500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/85 backdrop-blur-md"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ scale: 0.92, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.92, opacity: 0, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 260 }}
            className="relative w-full max-w-lg rounded-3xl border border-emerald-500/30 bg-slate-950/98 p-5 sm:p-6 text-white shadow-2xl backdrop-blur-2xl overflow-hidden max-h-[90vh] flex flex-col"
          >
            {/* Ambient Android Green Top Accent */}
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-500" />
            <div className="absolute -top-16 -right-16 w-36 h-36 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />

            {/* Header */}
            <div className="flex items-start justify-between mb-4 shrink-0">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-400 shadow-lg shadow-emerald-500/20">
                  <Smartphone size={24} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-display text-lg font-bold tracking-wide text-white">
                      ANDROID APP & APK
                    </h3>
                    <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 font-bold">
                      Native
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 font-mono">
                    Myraa AI Companion • Direct Mobile APK & Install
                  </p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="rounded-xl p-2 text-slate-400 hover:bg-white/10 hover:text-white transition cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Tab Navigation */}
            <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-white/5 border border-white/5 mb-4 text-xs font-mono shrink-0">
              <button
                onClick={() => setActiveTab("install")}
                className={`flex-1 py-2 px-3 rounded-xl transition cursor-pointer font-bold ${
                  activeTab === "install"
                    ? "bg-emerald-500 text-black shadow-md shadow-emerald-500/30"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                📲 1-Tap Install
              </button>
              <button
                onClick={() => setActiveTab("apk")}
                className={`flex-1 py-2 px-3 rounded-xl transition cursor-pointer font-bold ${
                  activeTab === "apk"
                    ? "bg-emerald-500 text-black shadow-md shadow-emerald-500/30"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                📦 Standalone APK
              </button>
              <button
                onClick={() => setActiveTab("features")}
                className={`flex-1 py-2 px-3 rounded-xl transition cursor-pointer font-bold ${
                  activeTab === "features"
                    ? "bg-emerald-500 text-black shadow-md shadow-emerald-500/30"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                ⚡ Features & Memory
              </button>
            </div>

            {/* Scrollable Content Area */}
            <div className="overflow-y-auto space-y-4 pr-1 text-sm custom-scrollbar">

              {/* TAB 1: 1-Tap Mobile Install */}
              {activeTab === "install" && (
                <div className="space-y-4">
                  {isInstalled ? (
                    <div className="p-4 rounded-2xl border border-emerald-500/30 bg-emerald-950/30 text-center">
                      <CheckCircle2 size={36} className="text-emerald-400 mx-auto mb-2" />
                      <h4 className="text-sm font-bold text-white">App Successfully Installed!</h4>
                      <p className="text-xs text-slate-300 mt-1">
                        Myraa aapke mobile ke Home screen aur App Drawer mein as a native Android app chal rahi hai.
                      </p>
                    </div>
                  ) : (
                    <div className="p-4 rounded-2xl border border-emerald-500/25 bg-emerald-950/25">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <h4 className="text-sm font-bold text-white">Direct Android App Installation (Fastest)</h4>
                          <p className="text-xs text-emerald-300">Google Chrome WebAPK Native Engine</p>
                        </div>
                        <span className="text-2xl">🤖</span>
                      </div>

                      <p className="text-xs text-slate-300 leading-relaxed mb-4">
                        Is button ko dabane se Google Chrome is app ko ek real <strong>Android App (WebAPK)</strong> me convert karke bina kisi build tool ke aapke phone me install kar deta hai. Browser bar gayab ho jayegi aur app full-screen chalegi!
                      </p>

                      <button
                        onClick={handleInstallClick}
                        className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-black font-bold text-xs sm:text-sm tracking-wide shadow-lg shadow-emerald-500/30 transition flex items-center justify-center gap-2 cursor-pointer active:scale-98"
                      >
                        <Download size={18} />
                        <span>INSTALL DIRECTLY TO PHONE (1-TAP)</span>
                      </button>

                      {!isInstallable && (
                        <p className="text-[11px] text-amber-300/90 text-center mt-2.5">
                          💡 Agar button se na ho, toh mobile Chrome ke top-right <strong>3 dots (⋮)</strong> &gt; <strong>&apos;Install app&apos;</strong> ya <strong>&apos;Add to Home screen&apos;</strong> par tap karein.
                        </p>
                      )}
                    </div>
                  )}

                  {/* Urdu/Hindi step by step instructions */}
                  <div className="p-3.5 rounded-2xl bg-white/5 border border-white/5 text-xs">
                    <h5 className="font-bold text-slate-200 mb-2 font-mono flex items-center gap-1.5">
                      <Sparkles size={14} className="text-emerald-400" />
                      <span>MOBILE PAR CHALANE KA ASAAN TAREEQA:</span>
                    </h5>
                    <ol className="space-y-1.5 text-slate-300 text-[11px] list-decimal list-inside leading-relaxed">
                      <li>Apne mobile ke <strong>Google Chrome</strong> mein is website ko kholein.</li>
                      <li>Upar diye gaye <strong>&apos;Install&apos;</strong> button ya Chrome menu ke <strong>&apos;Install app&apos;</strong> par tap karein.</li>
                      <li>Aapke mobile ke <strong>Home screen aur App Drawer</strong> par Myraa ka icon ban jayega!</li>
                      <li>Ab ye bilkul Play Store app ki tarah background voice, camera vision, aur torch control ke saath chalegi!</li>
                    </ol>
                  </div>
                </div>
              )}

              {/* TAB 2: Standalone APK & Project ZIP */}
              {activeTab === "apk" && (
                <div className="space-y-4">
                  {/* Notice explaining Page Not Found / External Scanners */}
                  <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-2.5 text-xs text-amber-200">
                    <Info size={18} className="shrink-0 text-amber-400 mt-0.5" />
                    <div>
                      <strong className="text-white block font-semibold mb-0.5">&quot;Page not found&quot; kyu aaya tha?</strong>
                      AI Studio ka development server Google login se protected hota hai, isliye PWABuilder jaisi external websites direct crawl nahi kar paati thin. Neeche diye gaye <strong>Direct Download</strong> se aap seedha APK build project le sakte hain!
                    </div>
                  </div>

                  {/* Method 1: Download Standalone Android Project ZIP */}
                  <div className="p-4 rounded-2xl border border-emerald-500/30 bg-emerald-950/20 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-bold text-white flex items-center gap-2">
                          <FolderArchive size={16} className="text-emerald-400" />
                          <span>Standalone Android Studio / Gradle Project (.zip)</span>
                        </h4>
                        <p className="text-[11px] text-slate-300 mt-0.5">
                          TWA Launcher, AndroidManifest, Gradle, aur App Icons ke saath complete project.
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={handleDownloadProjectZip}
                      disabled={isDownloadingZip}
                      className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-black font-bold text-xs font-mono transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 cursor-pointer active:scale-98"
                    >
                      <Download size={16} />
                      <span>{isDownloadingZip ? "Generating Project ZIP..." : "DOWNLOAD ANDROID PROJECT (.ZIP)"}</span>
                    </button>

                    <div className="p-2.5 rounded-xl bg-black/50 text-[11px] font-mono text-slate-300 space-y-1">
                      <div className="text-emerald-400 font-bold">APK Kaise Banayein (1-Minute):</div>
                      <p>1. Download hui zip ko extract karein.</p>
                      <p>2. Android Studio mein open karein aur <strong>Build &gt; Build APK</strong> dabayein.</p>
                      <p>Ya terminal mein run karein: <code className="text-emerald-300">./gradlew assembleDebug</code></p>
                      <p className="text-slate-400 text-[10px]">Output: <code className="text-slate-300">app/build/outputs/apk/debug/app-debug.apk</code></p>
                    </div>
                  </div>

                  {/* Method 2: PWABuilder with Custom URL */}
                  <div className="p-4 rounded-2xl border border-teal-500/20 bg-teal-950/20 space-y-3">
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <Globe size={16} className="text-teal-400" />
                      <span>PWABuilder Cloud APK Generator</span>
                    </h4>
                    <p className="text-[11px] text-slate-300">
                      Agar aapne app ko deploy kiya hai ya public domain hai, toh URL yahan dalein:
                    </p>

                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={customUrl}
                        onChange={(e) => setCustomUrl(e.target.value)}
                        placeholder="https://your-domain.com"
                        className="flex-1 bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                      />
                      <button
                        onClick={handleCopyUrl}
                        className="p-2 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 hover:text-white transition cursor-pointer"
                        title="Copy URL"
                      >
                        {copiedUrl ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                      </button>
                    </div>

                    <a
                      href={pwaBuilderUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2.5 px-3 rounded-xl bg-teal-500 hover:bg-teal-400 text-black font-bold text-xs font-mono transition flex items-center justify-between shadow-md"
                    >
                      <div className="flex items-center gap-2">
                        <Download size={15} />
                        <span>OPEN PWABUILDER WITH THIS URL</span>
                      </div>
                      <ExternalLink size={13} />
                    </a>
                  </div>

                  {/* TWA & Assetlinks Download */}
                  <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                    <a
                      href="/twa-manifest.json"
                      download="twa-manifest.json"
                      className="p-3 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition text-center block text-slate-300 hover:text-white"
                    >
                      <span className="block text-[10px] text-emerald-400">TWA BUILD CONFIG</span>
                      <span className="font-bold">twa-manifest.json</span>
                    </a>
                    <a
                      href="/.well-known/assetlinks.json"
                      download="assetlinks.json"
                      className="p-3 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition text-center block text-slate-300 hover:text-white"
                    >
                      <span className="block text-[10px] text-cyan-400">DIGITAL ASSETLINKS</span>
                      <span className="font-bold">assetlinks.json</span>
                    </a>
                  </div>
                </div>
              )}

              {/* TAB 3: Native Android Features & Memory */}
              {activeTab === "features" && (
                <div className="space-y-2.5 text-xs">
                  {[
                    { icon: <Sparkles size={16} className="text-emerald-400" />, title: "Permanent Long-Term Memory Core", desc: "Aap jitna bhi baat karenge, aapka naam, projects, goals, pasand-napasand sab Myraa hamesha yaad rakhegi." },
                    { icon: <Zap size={16} className="text-amber-400" />, title: "Continuous Background Voice", desc: "Back dabane par ya WhatsApp chalane par bhi Myraa ki voice call band nahi hoti." },
                    { icon: <Eye size={16} className="text-cyan-400" />, title: "Real-time Mobile Screen Vision", desc: "AI aapke phone ki screen aur apps dekh kar help kar sakti hai." },
                    { icon: <Layers size={16} className="text-purple-400" />, title: "Picture-in-Picture (PiP) Floating Avatar", desc: "Myraa ka avatar games aur apps ke upar float karta rehta hai." },
                    { icon: <Flashlight size={16} className="text-yellow-400" />, title: "Flashlight / Torch Control", desc: "'Torch on karo' bolne par mobile ki flashlight jal jati hai." },
                    { icon: <Vibrate size={16} className="text-sky-400" />, title: "Haptic Vibration", desc: "AI interaction par mobile vibrate hota hai." },
                    { icon: <ShieldCheck size={16} className="text-indigo-400" />, title: "Screen WakeLock", desc: "Baat karte waqt mobile screen lock nahi hoti." },
                  ].map((feat, idx) => (
                    <div key={idx} className="flex items-start gap-3 p-2.5 rounded-xl bg-white/5 border border-white/5">
                      <div className="p-1.5 rounded-lg bg-black/40 shrink-0 mt-0.5">{feat.icon}</div>
                      <div>
                        <h5 className="font-bold text-white text-[11px]">{feat.title}</h5>
                        <p className="text-[10px] text-slate-400">{feat.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between shrink-0">
              <span className="text-[10px] font-mono text-slate-400">
                Package: <span className="text-emerald-400">com.myraa.ai.companion</span>
              </span>
              <button
                onClick={onClose}
                className="py-1.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-mono font-bold text-white transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
