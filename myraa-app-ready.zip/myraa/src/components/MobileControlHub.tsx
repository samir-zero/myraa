import React, { useState, useEffect } from "react";
import { 
  Smartphone, 
  Battery, 
  BatteryCharging, 
  Wifi, 
  Flashlight, 
  Vibrate, 
  Share2, 
  Copy, 
  Check, 
  ExternalLink, 
  Clock, 
  Compass, 
  Camera, 
  Eye, 
  Tv, 
  Layers, 
  X, 
  ShieldCheck,
  Minimize2,
  Volume2,
  ChevronUp,
  Download
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { mobileController, DeviceDiagnostics, BatteryInfo } from "../lib/mobileController";
import { usePWAInstall } from "../lib/usePWAInstall";

interface MobileControlHubProps {
  isOpen: boolean;
  onClose: () => void;
  isScreenSharing: boolean;
  onToggleScreenShare: () => void;
  onToggleCameraVision: () => void;
  isCameraVisionActive: boolean;
  onInspectScreen: () => void;
  onOpenPiP: () => void;
  onOpenAndroidModal?: () => void;
  themeColor: string;
}

export const MobileControlHub: React.FC<MobileControlHubProps> = ({
  isOpen,
  onClose,
  isScreenSharing,
  onToggleScreenShare,
  onToggleCameraVision,
  isCameraVisionActive,
  onInspectScreen,
  onOpenPiP,
  onOpenAndroidModal,
  themeColor,
}) => {
  const [diagnostics, setDiagnostics] = useState<DeviceDiagnostics | null>(null);
  const [isTorchOn, setIsTorchOn] = useState(false);
  const [copied, setCopied] = useState(false);
  const [timerInput, setTimerInput] = useState("30");
  const [showTimerModal, setShowTimerModal] = useState(false);
  const [customAppInput, setCustomAppInput] = useState("");
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();

  // Refresh device diagnostics
  const refreshStats = async () => {
    const data = await mobileController.getDiagnostics();
    setDiagnostics(data);
    setIsTorchOn(mobileController.getTorchState());
  };

  useEffect(() => {
    if (isOpen) {
      refreshStats();
      const interval = setInterval(refreshStats, 5000);
      return () => clearInterval(interval);
    }
  }, [isOpen]);

  const handleToggleTorch = async () => {
    const result = await mobileController.toggleTorch();
    setIsTorchOn(result.state);
    mobileController.vibrate(60);
  };

  const handleVibrate = () => {
    mobileController.vibrate([150, 80, 200]);
  };

  const handleAppLaunch = (appName: string, query?: string) => {
    mobileController.vibrate(50);
    mobileController.openMobileApp(appName, query);
  };

  const handleCopyStatus = async () => {
    const statusText = `Myraa Mobile Assistant Status:\nBattery: ${
      diagnostics?.battery ? `${diagnostics.battery.level}%` : "N/A"
    }\nNetwork: ${diagnostics?.networkType || "Online"}\nScreen Vision: ${
      isScreenSharing ? "Active" : "Idle"
    }\nCamera Vision: ${isCameraVisionActive ? "Active" : "Idle"}`;
    await mobileController.copyToClipboard(statusText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md"
          />

          {/* Drawer container */}
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 26, stiffness: 220 }}
            className="fixed inset-x-0 bottom-0 z-50 max-h-[92vh] overflow-y-auto rounded-t-3xl border-t border-cyan-500/20 bg-slate-950/95 p-6 text-white shadow-2xl backdrop-blur-2xl max-w-2xl mx-auto"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-cyan-500/20 border border-cyan-400/30 text-cyan-300">
                  <Smartphone size={20} />
                </div>
                <div>
                  <h3 className="font-display text-base font-bold tracking-wide text-white">
                    MOBILE COMMAND & CONTROL
                  </h3>
                  <p className="text-[11px] font-mono text-cyan-400">
                    Full Phone Controller • Background Voice Active
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="rounded-xl p-2 text-slate-400 hover:bg-white/10 hover:text-white transition cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Live Phone Diagnostics Ribbon */}
            <div className="mt-4 grid grid-cols-3 gap-2.5">
              {/* Battery */}
              <div className="flex items-center gap-2.5 rounded-2xl border border-white/5 bg-white/5 p-3">
                {diagnostics?.battery?.charging ? (
                  <BatteryCharging size={20} className="text-emerald-400 animate-pulse" />
                ) : (
                  <Battery size={20} className="text-cyan-400" />
                )}
                <div>
                  <span className="block text-[9px] font-mono uppercase text-slate-400">Battery</span>
                  <span className="text-sm font-bold font-mono text-white">
                    {diagnostics?.battery ? `${diagnostics.battery.level}%` : "Ready"}
                  </span>
                </div>
              </div>

              {/* Network */}
              <div className="flex items-center gap-2.5 rounded-2xl border border-white/5 bg-white/5 p-3">
                <Wifi size={20} className="text-indigo-400" />
                <div>
                  <span className="block text-[9px] font-mono uppercase text-slate-400">Network</span>
                  <span className="text-sm font-bold font-mono text-white truncate max-w-[80px]">
                    {diagnostics?.networkType || "Online"}
                  </span>
                </div>
              </div>

              {/* Background Status */}
              <div className="flex items-center gap-2.5 rounded-2xl border border-emerald-500/20 bg-emerald-950/20 p-3">
                <ShieldCheck size={20} className="text-emerald-400" />
                <div>
                  <span className="block text-[9px] font-mono uppercase text-emerald-400">Bg Running</span>
                  <span className="text-[11px] font-bold font-mono text-emerald-200">
                    Active & Alive
                  </span>
                </div>
              </div>
            </div>

            {/* Android App & APK Center Card */}
            <div className="mt-4 rounded-2xl border border-emerald-500/30 bg-gradient-to-r from-emerald-950/40 via-teal-950/30 to-slate-950/60 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-400">
                    <span className="text-xl">🤖</span>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span>Android App & APK Center</span>
                      <span className="px-1.5 py-0.2 rounded bg-emerald-500/30 text-emerald-300 text-[9px] font-mono">
                        Native
                      </span>
                    </h4>
                    <p className="text-[10px] text-emerald-300/90">
                      Mobile Home Screen Install &amp; APK Download
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {onOpenAndroidModal && (
                    <button
                      onClick={onOpenAndroidModal}
                      className="rounded-xl bg-emerald-500 hover:bg-emerald-400 px-3 py-1.5 text-xs font-bold font-mono text-black transition shadow-md shadow-emerald-500/20 cursor-pointer"
                    >
                      Open Center
                    </button>
                  )}
                  {isInstallable && (
                    <button
                      onClick={install}
                      className="rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 px-2.5 py-1.5 text-xs font-mono text-white transition cursor-pointer"
                      title="1-Tap Install"
                    >
                      Install
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* VISION MODES SECTION (Dekh pae mobile me kya hai) */}
            <div className="mt-5">
              <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 block mb-2">
                Mobile Vision Stream (Gemini AI Eyes)
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Screen Share Vision */}
                <div
                  className={`flex items-center justify-between rounded-2xl border p-3.5 transition ${
                    isScreenSharing
                      ? "border-cyan-500 bg-cyan-950/30"
                      : "border-white/10 bg-white/5 hover:bg-white/10"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-300">
                      <Tv size={18} />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Phone Screen Vision</h4>
                      <p className="text-[10px] text-slate-400">
                        {isScreenSharing ? "Streaming full screen to AI" : "See apps, chats & documents"}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={onToggleScreenShare}
                    className={`rounded-xl px-3 py-1.5 text-xs font-mono font-bold transition cursor-pointer ${
                      isScreenSharing
                        ? "bg-rose-500 text-white hover:bg-rose-600"
                        : "bg-cyan-500 text-black hover:bg-cyan-400"
                    }`}
                  >
                    {isScreenSharing ? "Stop" : "Share"}
                  </button>
                </div>

                {/* Camera Lens Vision */}
                <div
                  className={`flex items-center justify-between rounded-2xl border p-3.5 transition ${
                    isCameraVisionActive
                      ? "border-purple-500 bg-purple-950/30"
                      : "border-white/10 bg-white/5 hover:bg-white/10"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-purple-500/20 text-purple-300">
                      <Camera size={18} />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Rear Camera Vision</h4>
                      <p className="text-[10px] text-slate-400">
                        {isCameraVisionActive ? "Looking through rear camera" : "Inspect objects or surroundings"}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={onToggleCameraVision}
                    className={`rounded-xl px-3 py-1.5 text-xs font-mono font-bold transition cursor-pointer ${
                      isCameraVisionActive
                        ? "bg-rose-500 text-white hover:bg-rose-600"
                        : "bg-purple-600 text-white hover:bg-purple-500"
                    }`}
                  >
                    {isCameraVisionActive ? "Stop" : "Camera"}
                  </button>
                </div>
              </div>

              {/* Instant Inspect Trigger */}
              {(isScreenSharing || isCameraVisionActive) && (
                <button
                  onClick={onInspectScreen}
                  className="mt-2.5 w-full flex items-center justify-center gap-2 rounded-xl bg-cyan-500/10 border border-cyan-400/30 py-2.5 text-xs font-mono font-semibold text-cyan-300 hover:bg-cyan-500/20 transition cursor-pointer"
                >
                  <Eye size={15} />
                  <span>Ask Myraa: &quot;Mere screen/mobile par kya hai?&quot;</span>
                </button>
              )}
            </div>

            {/* BACKGROUND MULTITASKING (Back karo toh bhi chale) */}
            <div className="mt-5">
              <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 block mb-2">
                Background & Multitasking Mode
              </span>
              <div className="rounded-2xl border border-indigo-500/20 bg-indigo-950/20 p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-300">
                      <Layers size={20} />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Floating Picture-in-Picture (PiP)</h4>
                      <p className="text-[10px] text-indigo-300">
                        Myraa floats on top while you switch to WhatsApp, Games, or Home
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={onOpenPiP}
                    className="rounded-xl bg-indigo-600 px-3 py-1.5 text-xs font-bold font-mono text-white hover:bg-indigo-500 transition shadow-lg cursor-pointer"
                  >
                    Float Avatar
                  </button>
                </div>
                <div className="mt-3 text-[11px] text-slate-300 bg-black/30 p-2.5 rounded-xl flex items-start gap-2">
                  <span className="text-cyan-400">💡</span>
                  <span>
                    <strong>Background Active:</strong> Jab aap Back dabayenge ya app minimize karenge, Myraa continuous voice audio mein aapse baatein karti rahegi!
                  </span>
                </div>
              </div>
            </div>

            {/* MOBILE QUICK APP LAUNCHERS */}
            <div className="mt-5">
              <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 block mb-2">
                Mobile Apps Control
              </span>
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                {[
                  { name: "WhatsApp", app: "whatsapp", icon: "💬", color: "bg-emerald-500/10 border-emerald-500/30 text-emerald-400" },
                  { name: "Phone", app: "phone", icon: "📞", color: "bg-blue-500/10 border-blue-500/30 text-blue-400" },
                  { name: "SMS", app: "sms", icon: "✉️", color: "bg-indigo-500/10 border-indigo-500/30 text-indigo-400" },
                  { name: "Maps", app: "maps", icon: "🗺️", color: "bg-amber-500/10 border-amber-500/30 text-amber-400" },
                  { name: "YouTube", app: "youtube", icon: "🎬", color: "bg-rose-500/10 border-rose-500/30 text-rose-400" },
                  { name: "Camera", app: "camera", icon: "📷", color: "bg-purple-500/10 border-purple-500/30 text-purple-400" },
                  { name: "Torch", app: "torch", icon: isTorchOn ? "💡" : "🔦", color: isTorchOn ? "bg-amber-400 text-black font-bold" : "bg-white/5 border-white/10 text-white" },
                  { name: "Vibrate", app: "vibrate", icon: "📳", color: "bg-cyan-500/10 border-cyan-500/30 text-cyan-400" },
                  { name: "Timer", app: "timer", icon: "⏰", color: "bg-sky-500/10 border-sky-500/30 text-sky-400" },
                  { name: "Search", app: "search", icon: "🔍", color: "bg-teal-500/10 border-teal-500/30 text-teal-400" },
                  { name: "Calc", app: "calculator", icon: "🔢", color: "bg-orange-500/10 border-orange-500/30 text-orange-400" },
                  { name: "Copy Info", app: "copy", icon: copied ? "✅" : "📋", color: "bg-slate-800 border-slate-700 text-slate-300" },
                ].map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      if (item.app === "torch") handleToggleTorch();
                      else if (item.app === "vibrate") handleVibrate();
                      else if (item.app === "copy") handleCopyStatus();
                      else if (item.app === "timer") setShowTimerModal(true);
                      else handleAppLaunch(item.app);
                    }}
                    className={`flex flex-col items-center justify-center p-2.5 rounded-2xl border text-center transition hover:scale-105 active:scale-95 cursor-pointer ${item.color}`}
                  >
                    <span className="text-xl mb-1">{item.icon}</span>
                    <span className="text-[10px] font-mono font-medium truncate w-full">{item.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Timer Modal */}
            {showTimerModal && (
              <div className="mt-4 p-4 rounded-2xl border border-sky-500/30 bg-sky-950/40">
                <h4 className="text-xs font-bold text-sky-200">Set Quick Alarm / Timer (seconds)</h4>
                <div className="mt-2 flex items-center gap-2">
                  <input
                    type="number"
                    value={timerInput}
                    onChange={(e) => setTimerInput(e.target.value)}
                    className="flex-1 rounded-xl bg-black/40 border border-white/10 px-3 py-1.5 text-sm text-white font-mono"
                    placeholder="Seconds (e.g. 30)"
                  />
                  <button
                    onClick={() => {
                      mobileController.setWebTimer(parseInt(timerInput, 10) || 30, "Myraa Voice Timer");
                      setShowTimerModal(false);
                      mobileController.vibrate(100);
                    }}
                    className="rounded-xl bg-sky-500 px-4 py-1.5 text-xs font-bold text-black hover:bg-sky-400"
                  >
                    Start
                  </button>
                  <button
                    onClick={() => setShowTimerModal(false)}
                    className="rounded-xl bg-white/10 px-3 py-1.5 text-xs text-slate-300"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {/* Close footer button */}
            <div className="mt-6">
              <button
                onClick={onClose}
                className="w-full rounded-2xl bg-white/10 py-3 text-xs font-mono font-bold tracking-wider uppercase text-slate-300 hover:bg-white/15 transition cursor-pointer"
              >
                Done / Return to Screen
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
