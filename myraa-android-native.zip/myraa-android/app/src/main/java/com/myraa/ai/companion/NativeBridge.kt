package com.myraa.ai.companion

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.webkit.JavascriptInterface
import androidx.core.content.ContextCompat
import org.json.JSONObject

/** Exposed to the web UI as window.MyraaNative. Every action returns {"success":bool,"message":string}. */
class NativeBridge(private val ctx: Context) {

    private fun ok(msg: String) = JSONObject().put("success", true).put("message", msg).toString()
    private fun fail(msg: String) = JSONObject().put("success", false).put("message", msg).toString()
    private fun a11y() = MyraaAccessibilityService.instance
    private val noA11y =
        "Accessibility control is OFF. Use enableAccessibility so the user can switch on Myraa in Settings > Accessibility."

    private fun launch(intent: Intent) {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    @JavascriptInterface
    fun isNative(): Boolean = true

    @JavascriptInterface
    fun isAccessibilityEnabled(): Boolean = a11y() != null

    @JavascriptInterface
    fun openAccessibilitySettings(): String = try {
        launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        ok("Accessibility settings opened. Ask the user to tap Myraa and switch it on.")
    } catch (e: Exception) {
        fail(e.message ?: "failed")
    }

    // ---------- Apps, calls, SMS ----------

    @JavascriptInterface
    fun openApp(app: String, target: String): String {
        val n = app.trim().lowercase()
        val q = target.trim()
        return try {
            when (n) {
                "phone", "call", "dialer" -> call(q)
                "sms", "message", "messages" -> {
                    launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).putExtra("sms_body", q))
                    ok("Messages app opened with the text pre-filled.")
                }
                "whatsapp" -> {
                    val digits = q.replace(Regex("[^0-9]"), "")
                    val uri: Uri? = when {
                        digits.length in 7..15 -> Uri.parse("https://wa.me/$digits")
                        q.isNotEmpty() -> Uri.parse("https://wa.me/?text=${Uri.encode(q)}")
                        else -> null
                    }
                    if (uri == null) launchByLabel("whatsapp")
                    else {
                        launch(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))
                        ok("WhatsApp opened.")
                    }
                }
                "maps", "navigation", "location" -> {
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(q)}")))
                    ok("Maps opened for \"$q\".")
                }
                "youtube" -> {
                    val uri = if (q.isEmpty()) "https://www.youtube.com"
                    else "https://www.youtube.com/results?search_query=${Uri.encode(q)}"
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse(uri)))
                    ok("YouTube opened.")
                }
                "camera" -> {
                    launch(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
                    ok("Camera opened.")
                }
                "settings" -> {
                    launch(Intent(Settings.ACTION_SETTINGS))
                    ok("Settings opened.")
                }
                "email", "mail" -> {
                    launch(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).putExtra(Intent.EXTRA_SUBJECT, q))
                    ok("Email app opened.")
                }
                "search", "google" -> {
                    launch(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
                    ok("Searching for \"$q\".")
                }
                "timer" -> {
                    val sec = q.toIntOrNull() ?: 60
                    launch(
                        Intent(AlarmClock.ACTION_SET_TIMER)
                            .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    )
                    ok("Timer set for $sec seconds.")
                }
                "alarm", "clock" -> {
                    launch(Intent(AlarmClock.ACTION_SHOW_ALARMS))
                    ok("Alarms opened.")
                }
                "calculator" -> {
                    launch(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
                    ok("Calculator opened.")
                }
                else -> launchByLabel(n)
            }
        } catch (e: Exception) {
            fail("Could not open $app: ${e.message}")
        }
    }

    private fun launchByLabel(name: String): String {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == name }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
            ?: return fail("No installed app found named \"$name\".")
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return fail("Cannot launch \"$name\".")
        launch(intent)
        return ok("${match.loadLabel(pm)} opened.")
    }

    @JavascriptInterface
    fun call(number: String): String {
        val clean = number.replace(Regex("[^0-9+*#]"), "")
        if (clean.isEmpty()) return fail("No phone number given.")
        return try {
            val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) ==
                PackageManager.PERMISSION_GRANTED
            val action = if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL
            launch(Intent(action, Uri.parse("tel:" + Uri.encode(clean))))
            ok(if (granted) "Calling $clean." else "Dialer opened with $clean.")
        } catch (e: Exception) {
            fail(e.message ?: "call failed")
        }
    }

    @JavascriptInterface
    fun sendSms(number: String, text: String): String = try {
        launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", text))
        ok("SMS composer opened for $number. Use clickText \"Send\" to send it.")
    } catch (e: Exception) {
        fail(e.message ?: "sms failed")
    }

    // ---------- Hardware ----------

    @JavascriptInterface
    fun setTorch(on: Boolean): String = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            val c = cm.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
        if (id == null) fail("No flashlight on this phone.")
        else {
            cm.setTorchMode(id, on)
            ok("Flashlight is now ${if (on) "ON" else "OFF"}.")
        }
    } catch (e: Exception) {
        fail(e.message ?: "torch failed")
    }

    @JavascriptInterface
    fun setVolume(percent: Int): String = try {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val p = percent.coerceIn(0, 100)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, max * p / 100, AudioManager.FLAG_SHOW_UI)
        ok("Media volume set to $p%.")
    } catch (e: Exception) {
        fail(e.message ?: "volume failed")
    }

    // ---------- Accessibility based control ----------

    @JavascriptInterface
    fun tap(x: Double, y: Double): String {
        val s = a11y() ?: return fail(noA11y)
        return if (s.tap(x.toFloat(), y.toFloat())) ok("Tapped at ($x, $y).") else fail("Tap failed.")
    }

    @JavascriptInterface
    fun swipe(x1: Double, y1: Double, x2: Double, y2: Double): String {
        val s = a11y() ?: return fail(noA11y)
        return if (s.swipe(x1.toFloat(), y1.toFloat(), x2.toFloat(), y2.toFloat())) ok("Swipe done.")
        else fail("Swipe failed.")
    }

    @JavascriptInterface
    fun scroll(direction: String): String {
        val s = a11y() ?: return fail(noA11y)
        return if (s.scroll(direction)) ok("Scrolled $direction.") else fail("Scroll failed.")
    }

    @JavascriptInterface
    fun globalAction(name: String): String {
        val s = a11y() ?: return fail(noA11y)
        return if (s.global(name)) ok("Pressed $name.") else fail("Action $name failed.")
    }

    @JavascriptInterface
    fun clickText(text: String): String {
        val s = a11y() ?: return fail(noA11y)
        return if (s.clickByText(text)) ok("Tapped \"$text\".") else fail("Could not find \"$text\" on screen.")
    }

    @JavascriptInterface
    fun typeText(text: String): String {
        val s = a11y() ?: return fail(noA11y)
        return if (s.typeText(text)) ok("Typed the text.") else fail("No text field is focused. Tap a text field first.")
    }

    @JavascriptInterface
    fun readScreen(): String {
        val s = a11y() ?: return fail(noA11y)
        return ok(s.readScreen())
    }
}
