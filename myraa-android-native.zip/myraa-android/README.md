# Myraa Native Android App

Ye app aapki Myraa web UI ko hubahu (same look, buttons, background) WebView me chalata hai,
aur upar se phone control deta hai: apps kholna, call, SMS, torch, volume, tap/swipe/type, screen padhna.

## Build (Android Studio)
1. Myraa server deploy karo (myraa-app-ready.zip ki DEPLOY.md dekho) aur HTTPS URL lo.
2. `gradle.properties` me `MYRAA_APP_URL=` ke aage apni URL daalo.
3. Android Studio -> File > Open -> is folder ko kholo -> Gradle sync hone do.
4. Build > Build APK(s). APK: app/build/outputs/apk/debug/app-debug.apk
5. APK phone me install karo.

## Pehli baar setup (phone par)
- Mic, camera, call permission "Allow" karo.
- Settings > Accessibility > Myraa > ON (tap/swipe/type/screen padhne ke liye).
  Ya Myraa se bolo: "enable accessibility".

## Limits
- Screen sharing (getDisplayMedia) WebView me support nahi; camera vision chalega.
- Banking/password screens par Android accessibility aksar block karta hai.
- Android lambe time background me mic pe sunne nahi deta (foreground service alag se jodni padegi).
